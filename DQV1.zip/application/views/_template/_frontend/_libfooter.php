<script src="<?= base_url('assets/') ?>front/js/jquery-3.2.1.min.js"></script>
<script src="<?= base_url('assets/') ?>front/styles/bootstrap4/popper.js"></script>
<script src="<?= base_url('assets/') ?>front/styles/bootstrap4/bootstrap.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/greensock/TweenMax.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/greensock/TimelineMax.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/greensock/animation.gsap.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
 <!-- DataTables JavaScript -->
<script src="<?= base_url('assets/') ?>front/plugins/easing/easing.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/parallax-js-master/parallax.min.js"></script>
<script src="<?= base_url('assets/') ?>front/plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="<?= base_url('assets/') ?>front/js/courses.js"></script>
<script src="<?= base_url('assets/') ?>front/js/custom.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
<script src="<?= base_url('assets/') ?>front/js/blog_single.js"></script>

<script>
   $(document).ready( function () {
	    $('#myTable').DataTable();
	} );
</script>