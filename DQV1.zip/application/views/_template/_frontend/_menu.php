<div class="menu_close_container">
		<div class="menu_close"><div></div><div></div></div></div>
			<div class="search">
				<form action="#" class="header_search_form menu_mm">
					<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
					<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
						<i class="fa fa-search menu_mm" aria-hidden="true"></i>
					</button>
				</form>
			</div>
	<nav class="menu_nav">
		<ul class="menu_mm">
			<li class="menu_mm"><a href="<?= base_url() ?>">Home</a></li>
			<!-- <li class="menu_mm"><a href="<?= base_url() ?>">Karya</a></li>  -->
			<!-- <li class="menu_mm"><a href="<?= base_url() ?>ppdb">PPDB</a></li> -->
			<li class="menu_mm"><a href="<?= base_url() ?>guru">Guru</a></li>
			<li class="menu_mm"><a href="<?= base_url() ?>siswa">Siswa</a></li>
			<li class="menu_mm"><a href="<?= base_url() ?>profile">Profile</a></li>
            <li class="menu_mm"><a href="<?= base_url() ?>berita">Berita</a></li>
            <li class="menu_mm"><a href="<?= base_url() ?>puisi">Puisi</a></li>
			<li class="menu_mm"><a href="<?= base_url() ?>pengumuman">Pengumuman</a></li>
			<li class="menu_mm"><a href="<?= base_url() ?>galery">Galery</a></li>
			<li class="menu_mm"><a href="<?= base_url() ?>download">Download</a></li>
			<li class="menu_mm"><a href="<?= base_url() ?>about">Tentang</a></li>
		</ul>
	</nav>