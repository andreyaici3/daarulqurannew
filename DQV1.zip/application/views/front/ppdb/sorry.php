<!DOCTYPE html>
<html>
<head>
	<title>PPDB Forbidden</title>
</head>
<body>

	<h1>Mohon Maaf, PPDB Daarul Qur'an Sudah Di tutup, Silahkan hubungi Staf TU untuk Informasi Pendaftaran Offline</h1>

</body>
</html>